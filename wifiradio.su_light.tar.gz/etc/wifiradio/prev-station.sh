#!/bin/sh  
cur=$(uci get wifiradio.@setting[0].current)   

maxnumb=$((0))
while read line
do
maxnumb=$(($maxnumb + 1))
done < /etc/wifiradio/playlist.m3u 

if [ $cur -ge 4 ]
        then  
                nx=$(($cur-2))
		else
				nx=$maxnumb
        fi 
		
uci set wifiradio.@setting[0].current=$nx
uci set wifiradio.@setting[0].pfp=0
uci commit wifiradio

killall wget 
killall madplay