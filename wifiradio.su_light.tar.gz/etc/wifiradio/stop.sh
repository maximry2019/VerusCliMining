#!/bin/sh
# ©2019 WifiRadio.su   
killall wget
killall madplay