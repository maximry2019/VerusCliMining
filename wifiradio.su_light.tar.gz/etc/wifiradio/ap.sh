#!/bin/sh
# ©2019 WifiRadio.su
	uci set wireless.radio0.disabled='0'
	uci set wireless.@wifi-iface[0].mode=ap
	uci set wireless.@wifi-iface[0].network='lan'
	uci set wireless.@wifi-iface[0].ssid="WifiRadio"
	uci set wireless.@wifi-iface[0].key="12345678"
	uci set wireless.@wifi-iface[0].encryption="psk2"
	uci set network.wwan.ipaddr="192.168.1.254"
	uci set network.wwan.proto=static
	
	uci commit network
	uci commit wireless; wifi