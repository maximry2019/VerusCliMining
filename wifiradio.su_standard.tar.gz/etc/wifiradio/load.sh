#!/bin/sh  
# ©2021 WifiRadio.su
sleep 7

uci set wifiradio.@setting[0].version_loc="116"
uci set wifiradio.@setting[0].server="http://fw.wifiradio.su"

sound=`amixer | grep -c 'Headphone'`
if [ $sound -eq 1 ]
then
uci set wifiradio.@setting[0].sound="Headphone"
fi

sound=`amixer | grep -c 'Speaker'`
if [ $sound -eq 1 ]
then
uci set wifiradio.@setting[0].sound="Speaker"
fi

sound=`amixer | grep -c 'PCM'`
if [ $sound -eq 1 ]
then
uci set wifiradio.@setting[0].sound="PCM"
fi

sound=`amixer | grep -c 'Speakers'`
if [ $sound -eq 1 ]
then
uci set wifiradio.@setting[0].sound="Speakers"
fi

uci commit wifiradio

mac=`ifconfig | head -1 | sed 's/ \+/ /g' | cut -d' ' -f5`

sleep 1

sound=$(uci get wifiradio.@setting[0].sound)
startvol=$(uci get wifiradio.@setting[0].startvol)
auto=$(uci get wifiradio.@setting[0].autoupdate)
server=$(uci get wifiradio.@setting[0].server)
time=$(uci get wifiradio.@setting[0].time)
wheater=$(uci get wifiradio.@setting[0].wheater)
station=$(uci get wifiradio.@setting[0].station)
ver=$(uci get wifiradio.@setting[0].version_loc)
hello=$(uci get wifiradio.@setting[0].hello)
tts=$(uci get wifiradio.@setting[0].tts)
city=$(uci get wifiradio.@setting[0].city)
updfw=$(uci get wifiradio.@setting[0].updfw)
vcfw=$(uci get wifiradio.@setting[0].vcfw)

amixer -c 0 -- sset $sound Playback Volume $startvol%

version_ser=`curl $server/download/fw_standard_gz | cat`

sleep 1

uci set wifiradio.@setting[0].version_ser=$version_ser

if [ $auto -eq 1 ]
then
curl -o "/tmp/playlists.tar.gz" $server/download/playlists_ru.tar.gz
tar -xzf "/tmp/playlists.tar.gz" -C "/etc/wifiradio/playlists/"
rm -r -f "/tmp/playlists.tar.gz"
/www/cgi-bin/wr_split
fi

curl -A "WifiRadio.SU" $server/tts.work/start.mp3 | madplay --replay-gain=audiophile --attenuate=-0 --stereo -

loca=$(uci get wifiradio.@setting[0].version_loc)
ser=$(uci get wifiradio.@setting[0].version_ser)

amixer -q set $sound 10%+

hello=${hello// /_}
if [ $hello != "_" ]
then
curl "$server/hello.php?hello=$hello&tts=$tts&mac=$mac"
sleep 1
curl -A "WifiRadio.SU" "$server/tts.hello/"$mac"_hello.mp3" | madplay --replay-gain=audiophile --attenuate=-0 --stereo -
fi

if [ $vcfw -eq 1 ]
then
if [ $ser -gt $loca ]
then
curl -A "WifiRadio.SU" $server/tts.work/$tts.update.mp3 | madplay --replay-gain=audiophile --attenuate=-0 --stereo -
fi
fi

if [ $time -eq 1 ]
then
utcz=`cat /etc/TZ`
len=`expr length $utcz`
utcz=`expr substr $utcz $len 1`
curl "$server/time.php?utcz=$utcz&tts=$tts&mac=$mac"
sleep 1
curl -A "WifiRadio.SU" "$server/tts.wtime/"$mac"_time.mp3" | madplay --replay-gain=audiophile --attenuate=-0 --stereo -
fi

if [ $wheater -eq 1 ]
then
city=${city//_/}
city=${city// /%20}
curl "$server/wheater.php?city=$city&mac=$mac&tts=$tts"
sleep 1
curl -A "WifiRadio.SU" "$server/tts.wtime/"$mac"_wheater.mp3" | madplay --replay-gain=audiophile --attenuate=-0 --stereo -
fi

amixer -q set $sound 10%-

uci set wifiradio.@setting[0].mute="0"
uci set wifiradio.@setting[0].fav="0"
uci set wifiradio.@setting[0].pfp="0"

uci commit wifiradio

/etc/wifiradio/play.sh $1 &
sleep 1
/etc/wifiradio/ping.sh $1 &
sleep 1
/etc/wifiradio/stt.sh $1 &

if [ $updfw -eq 1 ]
then
if [ $ser -gt $loca ]
then
sleep 90
/www/cgi-bin/wr_fw
fi
fi
